import os
from flask import Flask, request, render_template
import pandas as pd
import numpy as np

data = pd.read_csv('src/ProductPriceIndex.csv')
small_data = data[:5]

app = Flask(__name__)

image_names = ['strawberry.jpg', 'Romaine Lettuce.jpg','Red Leaf Lettuce.jpg', 'Potatoes.jpg', 'Oranges.jpg']

@app.route("/")
def home():
    import pandas as pd
    data = pd.read_csv('src/ProductPriceIndex.csv')
    data["farmprice"] = data["farmprice"].str.replace("$", "")
    data["atlantaretail"] = data["atlantaretail"].str.replace("$", "")
    data["chicagoretail"] = data["chicagoretail"].str.replace("$", "")
    data["losangelesretail"] = data["losangelesretail"].str.replace("$", "")
    data["newyorkretail"] = data["newyorkretail"].str.replace("$", "")
    data["averagespread"] = data["averagespread"].str.replace("%", "")
    small_data = data[:5]
    small_data1 = data[5:10]
    image_names = ['strawberry.jpg', 'Romaine Lettuce.jpg','Red Leaf Lettuce.jpg', 'Potatoes.jpg', 'Oranges.jpg']
    return render_template('start.html', items=small_data, image= image_names, items1=small_data1)

@app.route("/item")
def item():
    data = pd.read_csv('src/ProductPriceIndex.csv')
    data["farmprice"] = data["farmprice"].str.replace("$", "")
    data["atlantaretail"] = data["atlantaretail"].str.replace("$", "")
    data["chicagoretail"] = data["chicagoretail"].str.replace("$", "")
    data["losangelesretail"] = data["losangelesretail"].str.replace("$", "")
    data["newyorkretail"] = data["newyorkretail"].str.replace("$", "")
    data["averagespread"] = data["averagespread"].str.replace("%", "")
    image_names = ['strawberry.jpg', 'Romaine Lettuce.jpg','Red Leaf Lettuce.jpg', 'Potatoes.jpg', 'Oranges.jpg']
    name = request.args.get('name', default=None)
    image = request.args.get('image')
    price = request.args.get('price', default=None)
    price1 = ''
    price2 = ''
    price3 = ''
    price4 = ''
    for i in range(len(data)):
        if name.lower() == data['productname'][i].lower():
            price1 = data['atlantaretail'][i]
            price2 = data['chicagoretail'][i]
            price3 = data['losangelesretail'][i]
            price4 = data['newyorkretail'][i]
            date = data['date'][i]
            break
        
    price = round(float(price)*82.91, 2)
    price2 = round(float(price2)*82.91,2)
    price1 = round(float(price1)*82.91,2)
    price3 = round(float(price3)*82.91,2)
    price4 = round(float(price4)*82.91,2)
    return render_template('item.html', name=name, price=price,image=image,
                           price1= price1, price2= price2, price3=price3, price4=price4, date=date)


from flask import redirect

@app.route("/search")
def search():
    query = request.args.get('query', default=None)
    if query is None or query.strip() == "":
        return redirect("/")
    
    name = query.lower()
    data = pd.read_csv('src/ProductPriceIndex.csv')
    data["farmprice"] = data["farmprice"].str.replace("$", "")
    data["atlantaretail"] = data["atlantaretail"].str.replace("$", "")
    data["chicagoretail"] = data["chicagoretail"].str.replace("$", "")
    data["losangelesretail"] = data["losangelesretail"].str.replace("$", "")
    data["newyorkretail"] = data["newyorkretail"].str.replace("$", "")
    data["averagespread"] = data["averagespread"].str.replace("%", "")
    
    image_names = ['strawberry.jpg', 'Romaine Lettuce.jpg','Red Leaf Lettuce.jpg', 'Potatoes.jpg', 'Oranges.jpg']
    image = ''
    price = request.args.get('price', default=None)
    price1 = ''
    price2 = ''
    price3 = ''
    price4 = ''
    price = ''
    if name not in data['productname'].str.lower().values:
        return redirect("/")
    
    for i in range(len(data)):
        if name.lower() == data['productname'][i].lower():
            price = data['farmprice'][i]
            price1 = data['atlantaretail'][i]
            price2 = data['chicagoretail'][i]
            price3 = data['losangelesretail'][i]
            price4 = data['newyorkretail'][i]
            date = data['date'][i]
            break
    dummy = query.lower() + '.jpg'
    for i in range(len(image_names)):
        if dummy == image_names[i].lower():
            image = image_names[i]
            break
    else:
        image = 'Oranges.jpg'
    price = round(float(price)*82.91, 2)
    price2 = round(float(price2)*82.91,2)
    price1 = round(float(price1)*82.91,2)
    price3 = round(float(price3)*82.91,2)
    price4 = round(float(price4)*82.91,2)
    return render_template('item.html', name=name, price=price,image=image,
                           price1= price1, price2= price2, price3=price3, price4=price4, date=date)



if __name__ == "__main__":
    port = int(os.environ.get("PORT", 5000))
    app.run(debug=True, host="0.0.0.0", port=port)
