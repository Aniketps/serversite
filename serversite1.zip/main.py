import os
from flask import Flask, request, render_template, redirect, url_for
import pandas as pd
import requests

data = pd.read_csv('src/ProductPriceIndex.csv')
small_data = data[:5]

app = Flask(__name__)

def fetch_image_url(item_name):
    access_key = 'A9XfvxAy-tIETpFm4yrDdXzfszWXyt8ifUGq7EoWRyI'
    search_query = item_name.replace(' ', '+')
    url = f'https://api.unsplash.com/search/photos?query={search_query}&client_id={access_key}'
    response = requests.get(url)
    if response.status_code == 200:
        data = response.json()
        if data['results']:
            return data['results'][0]['urls']['regular']
    return None

@app.route("/")
def home():
    data = pd.read_csv('src/ProductPriceIndex.csv')
    data["farmprice"] = data["farmprice"].str.replace("$", "")
    data["atlantaretail"] = data["atlantaretail"].str.replace("$", "")
    data["chicagoretail"] = data["chicagoretail"].str.replace("$", "")
    data["losangelesretail"] = data["losangelesretail"].str.replace("$", "")
    data["newyorkretail"] = data["newyorkretail"].str.replace("$", "")
    data["averagespread"] = data["averagespread"].str.replace("%", "")
    data = data.drop_duplicates()
    small_data = data[:5]
    small_data1 = data[5:150]

    image_urls = {}
    for item_name in small_data1['productname']:
        image_urls[item_name] = fetch_image_url(item_name)

    default_image = 'static/Tomato2.jpg'

    return render_template('start.html', items=small_data,items1=small_data1, image_urls=image_urls, default_image=default_image)


@app.route("/item")
def item():
    data = pd.read_csv('src/ProductPriceIndex.csv')
    data["farmprice"] = data["farmprice"].str.replace("$", "")
    data["atlantaretail"] = data["atlantaretail"].str.replace("$", "")
    data["chicagoretail"] = data["chicagoretail"].str.replace("$", "")
    data["losangelesretail"] = data["losangelesretail"].str.replace("$", "")
    data["newyorkretail"] = data["newyorkretail"].str.replace("$", "")
    data["averagespread"] = data["averagespread"].str.replace("%", "")
    image_names = ['strawberry.jpg', 'Romaine Lettuce.jpg','Red Leaf Lettuce.jpg', 'Potatoes.jpg', 'Oranges.jpg']
    name = request.args.get('name', default=None)
    image = request.args.get('image')
    price = request.args.get('price', default=None)
    price1 = ''
    price2 = ''
    price3 = ''
    price4 = ''
    for i in range(len(data)):
        if name.lower() == data['productname'][i].lower():
            price1 = data['atlantaretail'][i]
            price2 = data['chicagoretail'][i]
            price3 = data['losangelesretail'][i]
            price4 = data['newyorkretail'][i]
            date = data['date'][i]
            break
        
    price = round(float(price)*82.91, 2)
    price2 = round(float(price2)*82.91,2)
    price1 = round(float(price1)*82.91,2)
    price3 = round(float(price3)*82.91,2)
    price4 = round(float(price4)*82.91,2)
    return render_template('item.html', name=name, price=price,image=image,
                           price1= price1, price2= price2, price3=price3, price4=price4, date=date)


from flask import redirect

@app.route("/search")
def search():
    query = request.args.get('query', default=None)
    if query is None or query.strip() == "":
        return redirect("/")
    
    name = query.lower()
    data = pd.read_csv('src/ProductPriceIndex.csv')
    data["farmprice"] = data["farmprice"].str.replace("$", "")
    data["atlantaretail"] = data["atlantaretail"].str.replace("$", "")
    data["chicagoretail"] = data["chicagoretail"].str.replace("$", "")
    data["losangelesretail"] = data["losangelesretail"].str.replace("$", "")
    data["newyorkretail"] = data["newyorkretail"].str.replace("$", "")
    data["averagespread"] = data["averagespread"].str.replace("%", "")
    
    image_names = fetch_image_url(name)
    price = request.args.get('price', default=None)
    price1 = ''
    price2 = ''
    price3 = ''
    price4 = ''
    price = ''
    if name not in data['productname'].str.lower().values:
        return redirect("/")
    
    for i in range(len(data)):
        if name.lower() == data['productname'][i].lower():
            price = data['farmprice'][i]
            price1 = data['atlantaretail'][i]
            price2 = data['chicagoretail'][i]
            price3 = data['losangelesretail'][i]
            price4 = data['newyorkretail'][i]
            date = data['date'][i]
            break

    price = round(float(price)*82.91, 2)
    price2 = round(float(price2)*82.91,2)
    price1 = round(float(price1)*82.91,2)
    price3 = round(float(price3)*82.91,2)
    price4 = round(float(price4)*82.91,2)
    return render_template('item.html', name=name, price=price,image=image_names,
                           price1= price1, price2= price2, price3=price3, price4=price4, date=date)

@app.route("/buy")
def buy():
    name = request.args.get('name')
    price = request.args.get('price')
    return render_template('buy_product.html', name=name,price=price)

@app.route("/place_order", methods=["POST"])
def order():
    item_name = request.form.get('item_name')
    quantity = request.form.get('quantity')
    user_name = request.form.get('name')
    gmail = request.form.get('email')
    price = request.form.get('item_price')
    address = request.form.get('address')
    price = float(price)
    quantity = int(quantity)
    total_price = float(price) * int(quantity)

    print(item_name)
    print(quantity)
    print(user_name)
    print(gmail)
    print(price)
    print(address)
    print(total_price)
    return render_template('complete.html')

if __name__ == "__main__":
    port = int(os.environ.get("PORT", 8503))  # Change the port number to 8502
    app.run(debug=True, host="0.0.0.0", port=port, use_reloader=False)
